import { Injectable } from '@angular/core';

import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AuthenticationService } from './service/authentication.service';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  constructor(private auth: AuthenticationService, private router: Router) {}

  canActivate() {
    if (!this.auth.isLoggedIn()) {
      this.router.navigateByUrl('/');
      return false;
    }
    return true;
  }
}

//   constructor(private router: Router,private http:HttpClient) { }

//   registerUser(user){
//     this.http.post('http://localhost:3000/users/register',user)
//     .subscribe(data=>
//       console.log(data),
//       err=>console.log(err)
//       )}
     
//       authenticateUser(user){

//        this.http.post('http://localhost:3000/users/authenticate',user)
//     .subscribe(data=>
//       console.log(data),
//       err=>console.log(err)
//       )}
  //   canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
  //       if (localStorage.getItem('currentUser')) {
  //           // logged in so return true
  //           return true;
  //       }

  //       // not logged in so redirect to login page with the return url
  //       this.router.navigate(['login'], { queryParams: { returnUrl: state.url }});
  //       return false
  // }


