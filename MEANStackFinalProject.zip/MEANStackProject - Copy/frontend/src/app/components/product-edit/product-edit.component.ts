
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ProductService } from '../product.service';
import { ProductModel } from '../product-list/product.model';


@Component({
  selector: 'app-product-edit',
  templateUrl: './product-edit.component.html',
  styleUrls: ['./product-edit.component.css']
})

export class ProductEditComponent implements OnInit {
  
  submitted = false;
  angForm:FormGroup;
  products: ProductModel[];
  title:String = "Edit Product";

  constructor(
    private productService: ProductService,
    private actRoute: ActivatedRoute,
    private router: Router,
    private fb:FormBuilder) {}
    
  ngOnInit(): void {
    this.updateProduct();
    let id = this.actRoute.snapshot.paramMap.get('id');
    this.getProduct(id);
    alert(this.getProduct(id))
    this.angForm = this.fb.group({
      productId: ['', Validators.required],
      productName: ['', Validators.required],
      productCode: ['', Validators.required],
    releaseDate: ['', Validators.required],
    description: ['', Validators.required],
    price: ['', Validators.required],
    starRating: ['', Validators.required],
    imageUrl: ['', Validators.required]
    })
  }

 // Getter to access form control
 get myForm() {
  return this.angForm.controls;
}

getProduct(id) {
  this.productService.getProduct(id).subscribe(data => {
    this.angForm.setValue({
      productId: data['productId'],
      productName: data['productName'],
      productCode: data['productCode'],
    releaseDate: data['releaseDate'],
    description: data['description'],
    price: data['price'],
    starRating: data['starRating'],
    imageUrl:data['imageUrl']
    })
    });
  }


updateProduct() {
  this.angForm = this.fb.group({
    productId: ['', Validators.required],
    productName: ['', Validators.required],
    productCode: ['', Validators.required],
  releaseDate: ['', Validators.required],
  description: ['', Validators.required],
  price: ['', Validators.required],
  starRating: ['', Validators.required],
  imageUrl: ['', Validators.required]
  })
}

onSubmit() {
  this.submitted = true;
  if (!this.angForm.valid) {
    return false;
  } else {
    if (window.confirm('Are you sure?')) {
      let id = this.actRoute.snapshot.paramMap.get('id');
      this.productService.updateProduct(id, this.angForm.value)
        .subscribe(res => {
          this.router.navigateByUrl('/product-list');
          console.log('Content updated successfully!')
        }, (error) => {
          console.log(error)
        })
    }
  }
}
}