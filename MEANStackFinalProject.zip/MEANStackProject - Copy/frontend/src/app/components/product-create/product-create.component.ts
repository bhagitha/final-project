import { Router } from '@angular/router';
import { ApiService } from './../../service/api.service';
import { Component, OnInit, NgZone } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ProductService } from '../product.service';
import { ProductModel } from '../product-list/product.model';

@Component({
  selector: 'app-product-create',
  templateUrl: './product-create.component.html',
  styleUrls: ['./product-create.component.css']
})

export class ProductCreateComponent implements OnInit {  
  title:String = "Add Designs";
  constructor(private productService: ProductService,private router: Router) { }
  productItem=new ProductModel(null,null,null,null,null,null,null,null);
  
  ngOnInit(): void {
  }
  AddProduct()
  {
    this.productService.newProduct(this.productItem);
        console.log('product successfully created!')
         this.router.navigateByUrl('/products-list')
  }

}