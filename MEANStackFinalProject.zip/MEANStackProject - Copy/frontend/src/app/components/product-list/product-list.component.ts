import { Component, OnInit } from '@angular/core';
import { ProductModel } from './product.model';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  constructor(private productService:ProductService) { }
title:String = "Check latest Designs";
products: ProductModel[];
imageWidth: number =50;
imageMargin: number = 2;
showImage: boolean = false;
toggleImage():void{
  this.showImage = !this.showImage;
}
  ngOnInit(): void {
    alert("hii")
    this.productService.getProducts().subscribe((data)=>{
      this.products=JSON.parse(JSON.stringify(data));
    })
  }
  removeProduct(products, index) {
    if(window.confirm('Are you sure?')) {
        this.productService.deleteProduct(products._id).subscribe((data) => {
          this.products.splice(index, 1);
  })}}}
