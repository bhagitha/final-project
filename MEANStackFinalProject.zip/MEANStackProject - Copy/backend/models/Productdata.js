const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/productdb',
{
    useNewUrlParser: true,
    useUnifiedTopology:true
}).then(() => {
    console.log('Database sucessfully connected')
 },
 error => {
    console.log('Database could not connected: ' + error)
 }
)
const Schema=mongoose.Schema;//schema definition

const NewProductSchema = new Schema({
    productId : Number,
    productName: String,
    productCode: String,
    releaseDate: String,
    description : String,
    price : Number,
    starRating : Number,
    imageUrl : String
},{strict:false});

var Productdata = mongoose.model('product',NewProductSchema);

module.exports = Productdata;
